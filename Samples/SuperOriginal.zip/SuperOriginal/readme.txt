My name is Marcelo Neves,

I'm a programmer since 1988 xBase (Clipper),
live in the city of Curitiba, Parana, Brazil.
For some years I am user of MiniGUI Extended,
realized several projects and earned good money,
so I decided to give a contribution to the samples folder,
which would be a complete system for pizza,
so that more and more developers use this wonderful tool,
and perhaps with an example like this,
it becomes easier the transition from Clipper to Harbour,
or the text mode to graphics mode.

July, 2012